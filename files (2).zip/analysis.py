"""
Data Analysis Project - Sales Performance Analysis
Intern Data Analysis Project
"""

import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import seaborn as sns
import numpy as np
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────
# 1. LOAD & EXPLORE DATA
# ─────────────────────────────────────────────
print("=" * 55)
print("   SALES DATA ANALYSIS - INTERN PROJECT")
print("=" * 55)

df = pd.read_csv("sales_data.csv")

print("\n📋 Dataset Overview:")
print(f"   Rows: {df.shape[0]}  |  Columns: {df.shape[1]}")
print(f"\n   Columns: {list(df.columns)}")
print(f"\n   Data Types:\n{df.dtypes}")
print(f"\n   Missing Values: {df.isnull().sum().sum()}")

# ─────────────────────────────────────────────
# 2. BASIC STATISTICS
# ─────────────────────────────────────────────
print("\n📊 Summary Statistics:")
print(df[['Sales', 'Units', 'Profit']].describe().round(2))

# ─────────────────────────────────────────────
# 3. ANALYSIS
# ─────────────────────────────────────────────

# Total Sales by Region
region_sales = df.groupby('Region')['Sales'].sum().sort_values(ascending=False)
print("\n🌍 Total Sales by Region:")
for region, val in region_sales.items():
    print(f"   {region}: ${val:,.0f}")

# Total Sales by Product
product_sales = df.groupby('Product')['Sales'].sum().sort_values(ascending=False)
print("\n📦 Total Sales by Product:")
for product, val in product_sales.items():
    print(f"   {product}: ${val:,.0f}")

# Monthly Sales Trend
monthly_sales = df.groupby('Month')['Sales'].sum()
month_order = ['January','February','March','April','May','June']
monthly_sales = monthly_sales.reindex(month_order)
print("\n📅 Monthly Sales Trend:")
for month, val in monthly_sales.items():
    print(f"   {month}: ${val:,.0f}")

# Profit Margin
df['Profit_Margin'] = (df['Profit'] / df['Sales'] * 100).round(2)
avg_margin = df['Profit_Margin'].mean()
print(f"\n💰 Average Profit Margin: {avg_margin:.1f}%")

best_product = df.groupby('Product')['Profit_Margin'].mean().idxmax()
print(f"   Best Margin Product: {best_product}")

# ─────────────────────────────────────────────
# 4. VISUALIZATIONS
# ─────────────────────────────────────────────
print("\n🎨 Generating visualizations...")

sns.set_theme(style="whitegrid", palette="muted")
fig = plt.figure(figsize=(16, 12))
fig.suptitle("Sales Performance Dashboard", fontsize=18, fontweight='bold', y=0.98)
gs = gridspec.GridSpec(2, 2, figure=fig, hspace=0.4, wspace=0.35)

# --- Chart 1: Sales by Region (Bar) ---
ax1 = fig.add_subplot(gs[0, 0])
colors = sns.color_palette("Blues_d", len(region_sales))
bars = ax1.bar(region_sales.index, region_sales.values, color=colors, edgecolor='white', linewidth=1.2)
ax1.set_title("Total Sales by Region", fontweight='bold', fontsize=13)
ax1.set_xlabel("Region")
ax1.set_ylabel("Sales ($)")
for bar, val in zip(bars, region_sales.values):
    ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 500,
             f'${val/1000:.0f}K', ha='center', va='bottom', fontsize=9, fontweight='bold')
ax1.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'${x/1000:.0f}K'))

# --- Chart 2: Product Sales Share (Pie) ---
ax2 = fig.add_subplot(gs[0, 1])
explode = [0.05] * len(product_sales)
wedge_colors = sns.color_palette("Set2", len(product_sales))
ax2.pie(product_sales.values, labels=product_sales.index, autopct='%1.1f%%',
        colors=wedge_colors, explode=explode, startangle=90,
        textprops={'fontsize': 10})
ax2.set_title("Sales Share by Product", fontweight='bold', fontsize=13)

# --- Chart 3: Monthly Sales Trend (Line) ---
ax3 = fig.add_subplot(gs[1, 0])
ax3.plot(month_order, monthly_sales.values, marker='o', linewidth=2.5,
         color='steelblue', markersize=8, markerfacecolor='white', markeredgewidth=2)
ax3.fill_between(month_order, monthly_sales.values, alpha=0.15, color='steelblue')
ax3.set_title("Monthly Sales Trend", fontweight='bold', fontsize=13)
ax3.set_xlabel("Month")
ax3.set_ylabel("Total Sales ($)")
ax3.tick_params(axis='x', rotation=30)
for i, (m, v) in enumerate(zip(month_order, monthly_sales.values)):
    ax3.annotate(f'${v/1000:.0f}K', (m, v), textcoords="offset points",
                 xytext=(0, 10), ha='center', fontsize=8)
ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda x, _: f'${x/1000:.0f}K'))

# --- Chart 4: Profit Margin by Product & Region (Heatmap) ---
ax4 = fig.add_subplot(gs[1, 1])
pivot = df.pivot_table(values='Profit_Margin', index='Product', columns='Region', aggfunc='mean').round(1)
sns.heatmap(pivot, annot=True, fmt='.1f', cmap='YlGn', ax=ax4,
            linewidths=0.5, cbar_kws={'label': 'Margin %'})
ax4.set_title("Profit Margin % by Product & Region", fontweight='bold', fontsize=13)
ax4.set_xlabel("Region")
ax4.set_ylabel("Product")

plt.savefig("sales_dashboard.png", dpi=150, bbox_inches='tight', facecolor='white')
print("   ✅ Dashboard saved: sales_dashboard.png")

# ─────────────────────────────────────────────
# 5. KEY INSIGHTS
# ─────────────────────────────────────────────
print("\n" + "=" * 55)
print("   KEY INSIGHTS")
print("=" * 55)
print(f"   ✔ Top Region:   {region_sales.idxmax()} (${region_sales.max():,.0f})")
print(f"   ✔ Top Product:  {product_sales.idxmax()} (${product_sales.max():,.0f})")
print(f"   ✔ Best Month:   {monthly_sales.idxmax()} (${monthly_sales.max():,.0f})")
print(f"   ✔ Avg Margin:   {avg_margin:.1f}%")
print(f"   ✔ Total Revenue:${df['Sales'].sum():,.0f}")
print(f"   ✔ Total Profit: ${df['Profit'].sum():,.0f}")
print("=" * 55)
print("\n✅ Analysis complete!")
