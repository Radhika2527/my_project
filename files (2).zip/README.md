# 📊 Sales Data Analysis Project

**Intern ID:** YOUR_INTERN_ID_HERE

---

## 📌 Project Overview

This project performs exploratory data analysis (EDA) on a retail sales dataset covering 6 months across 4 regions and 3 product categories. It uncovers trends, patterns, and key business insights through Python data analysis and visualizations.

---

## 📁 Project Structure

```
data_analysis_project/
│
├── sales_data.csv       # Dataset (24 records, 6 columns)
├── analysis.py          # Main analysis script
├── sales_dashboard.png  # Output: 4-chart visualization dashboard
└── README.md            # Project documentation
```

---

## 🛠️ Tools & Libraries Used

| Library       | Purpose                        |
|---------------|-------------------------------|
| `pandas`      | Data loading & manipulation   |
| `matplotlib`  | Chart plotting                |
| `seaborn`     | Statistical visualizations    |
| `numpy`       | Numerical operations          |

---

## 📊 Dataset Description

**File:** `sales_data.csv`

| Column  | Description                   |
|---------|-------------------------------|
| Month   | Month of sales record         |
| Region  | Sales region (North/South/East/West) |
| Product | Product category (Laptop/Phone/Tablet) |
| Sales   | Total sales amount ($)        |
| Units   | Number of units sold          |
| Profit  | Profit earned ($)             |

---

## 🔍 Analysis Performed

1. **Data Exploration** – Shape, data types, missing values check
2. **Summary Statistics** – Mean, min, max, std for numeric columns
3. **Sales by Region** – Which region generates the most revenue
4. **Sales by Product** – Best-performing product category
5. **Monthly Trend** – Sales growth over 6 months
6. **Profit Margin Analysis** – Margin % by product and region

---

## 📈 Key Insights

- ✔ **Top Region:** North ($249,000 in total sales)
- ✔ **Top Product:** Laptop ($500,000 — over 55% of total revenue)
- ✔ **Best Month:** June ($181,000 — highest monthly sales)
- ✔ **Avg Profit Margin:** 30%
- ✔ **Total Revenue:** $896,000
- ✔ **Total Profit:** $268,800

---

## ▶️ How to Run

1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/data-analysis-project.git
   cd data-analysis-project
   ```

2. Install dependencies:
   ```bash
   pip install pandas matplotlib seaborn numpy
   ```

3. Run the analysis:
   ```bash
   python analysis.py
   ```

4. Output: A `sales_dashboard.png` file will be generated with 4 charts.

---

## 📸 Dashboard Preview

The script generates a 4-panel dashboard:
- 📊 Bar Chart – Sales by Region
- 🥧 Pie Chart – Product Sales Share
- 📈 Line Chart – Monthly Sales Trend
- 🔥 Heatmap – Profit Margin by Product & Region

---

## 👤 Author

- **Role:** Data Analysis Intern
- **Intern ID:** YOUR_INTERN_ID_HERE
